require("./src/calc.js").run()
